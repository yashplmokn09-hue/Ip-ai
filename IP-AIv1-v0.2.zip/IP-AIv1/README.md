# IP-AIv1 v0.2

An original, small Transformer language-model project with a browser chat UI and an API.

## What changed
- Upgraded the default architecture to 6 Transformer blocks, 192 hidden size, 6 attention heads and a 256-token context window.
- Added lazy model loading and a health endpoint.
- Added a clean browser chat UI at `/`.
- Added conversation history in the UI.
- Added bounded generation settings in the API.
- Kept the project independent of proprietary model weights.

## Important
This is **not** GPT-5.6 Luna. It is a small educational model. Frontier-level quality requires vastly more data, training compute, evaluation and engineering. GPT-5.6 Luna itself supports a large context window and tools such as function calling, web search, file search and code interpreter; IP-AIv1 will need to build those capabilities independently over time.

## Try it locally

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python train.py
uvicorn api:app --reload
```

Open `http://127.0.0.1:8000` in a browser.

API docs: `http://127.0.0.1:8000/docs`
Health: `http://127.0.0.1:8000/health`

## Next upgrades
1. BPE/SentencePiece tokenizer
2. Better open training data pipeline
3. Instruction tuning and evaluation
4. Retrieval + safe web tools
5. Tool/function calling
6. Longer context + KV cache
7. Better UI streaming
8. Deployment on suitable free/low-cost compute when available
