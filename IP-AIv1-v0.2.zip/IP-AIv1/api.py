from pathlib import Path
import uuid
import torch
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from ip_ai.model import IPAIv1
from ip_ai.tokenizer import CharTokenizer
from ip_ai.generate import generate

APP_VERSION = "0.2.0"
OUT = Path("artifacts")
app = FastAPI(title="IP-AIv1 API", version=APP_VERSION)

# Load artifacts lazily so /health and the UI can still start before training.
model = None
tok = None


def load_model():
    global model, tok
    if model is not None:
        return
    tok_path = OUT / "tokenizer.json"
    model_path = OUT / "model.pt"
    if not tok_path.exists() or not model_path.exists():
        return
    tok = CharTokenizer(path=tok_path)
    model = IPAIv1(tok.vocab_size, block_size=256, d_model=192, n_layers=6, n_heads=6)
    state = torch.load(model_path, map_location="cpu")
    model.load_state_dict(state)
    model.eval()


class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: list[Message] = Field(min_length=1)
    max_tokens: int = Field(default=160, ge=1, le=512)
    temperature: float = Field(default=0.8, ge=0.05, le=2.0)


@app.on_event("startup")
def startup():
    load_model()


@app.get("/health")
def health():
    return {
        "model": "IP-AIv1",
        "version": APP_VERSION,
        "status": "ok",
        "weights_loaded": model is not None,
    }


@app.get("/", response_class=HTMLResponse)
def ui():
    return HTMLResponse((Path(__file__).parent / "ui.html").read_text(encoding="utf-8"))


@app.post("/v1/chat/completions")
def chat(req: ChatRequest):
    load_model()
    if model is None or tok is None:
        return {
            "id": f"ip-aiv1-{uuid.uuid4().hex[:12]}",
            "object": "chat.completion",
            "model": "IP-AIv1",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "IP-AIv1 weights are not trained yet. Run `python train.py` first."}, "finish_reason": "error"}],
        }

    # Keep the newest context that fits the model window.
    prompt = "\n".join(f"{m.role}: {m.content}" for m in req.messages)
    prompt += "\nassistant: "
    output = generate(model, tok, prompt, req.max_tokens, req.temperature)
    answer = output[len(prompt):] if output.startswith(prompt) else output
    return {
        "id": f"ip-aiv1-{uuid.uuid4().hex[:12]}",
        "object": "chat.completion",
        "model": "IP-AIv1",
        "choices": [{"index": 0, "message": {"role": "assistant", "content": answer.strip()}, "finish_reason": "length"}],
    }
