import torch

@torch.no_grad()
def generate(model, tokenizer, prompt, max_new_tokens=100, temperature=0.8, top_k=40):
    model.eval()
    device = next(model.parameters()).device
    ids = tokenizer.encode(prompt)
    if not ids:
        return prompt
    x = torch.tensor([ids[-model.block_size:]], dtype=torch.long, device=device)
    for _ in range(max_new_tokens):
        logits, _ = model(x)
        logits = logits[:, -1, :] / max(temperature, 1e-5)
        if top_k:
            values, _ = torch.topk(logits, min(top_k, logits.size(-1)))
            logits[logits < values[:, [-1]]] = float("-inf")
        probs = torch.softmax(logits, dim=-1)
        next_id = torch.multinomial(probs, 1)
        x = torch.cat([x, next_id], dim=1)[:, -model.block_size:]
    return tokenizer.decode(x[0].tolist())
