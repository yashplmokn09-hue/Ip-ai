import json
from pathlib import Path

class CharTokenizer:
    """Simple v0 tokenizer. We can replace this with a BPE tokenizer later."""
    def __init__(self, text=None, path=None):
        if path:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self.stoi = data["stoi"]
            self.itos = {int(k): v for k, v in data["itos"].items()}
        else:
            chars = sorted(set(text or ""))
            self.stoi = {ch: i for i, ch in enumerate(chars)}
            self.itos = {i: ch for ch, i in self.stoi.items()}

    @property
    def vocab_size(self):
        return len(self.stoi)

    def encode(self, text):
        return [self.stoi.get(ch, 0) for ch in text]

    def decode(self, ids):
        return "".join(self.itos.get(int(i), "") for i in ids)

    def save(self, path):
        Path(path).write_text(json.dumps({"stoi": self.stoi, "itos": self.itos}, ensure_ascii=False), encoding="utf-8")
