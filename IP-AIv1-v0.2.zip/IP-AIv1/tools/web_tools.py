"""Internet tool interface for IP-AIv1.

v0.1 defines the boundary only. The production implementation will add
safe search/fetch providers and source extraction without making the model
itself dependent on another AI API.
"""

from urllib.parse import quote
import urllib.request

def fetch_url(url: str, timeout=10) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "IP-AIv1/0.1"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    return raw.decode("utf-8", errors="ignore")

def search_url(query: str) -> str:
    # Placeholder endpoint; provider selection comes in the internet layer.
    return "https://www.google.com/search?q=" + quote(query)
