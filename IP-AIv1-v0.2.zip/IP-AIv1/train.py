from pathlib import Path
import torch
from ip_ai.model import IPAIv1
from ip_ai.tokenizer import CharTokenizer

DATA = Path("data/train.txt")
OUT = Path("artifacts")
OUT.mkdir(exist_ok=True)

text = DATA.read_text(encoding="utf-8")
tok = CharTokenizer(text=text)
tok.save(OUT / "tokenizer.json")

device = "cuda" if torch.cuda.is_available() else "cpu"
model = IPAIv1(tok.vocab_size, block_size=256, d_model=192, n_layers=6, n_heads=6).to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4)

ids = torch.tensor(tok.encode(text), dtype=torch.long)
block = model.block_size

for step in range(800):
    if len(ids) <= block + 1:
        raise ValueError("Training text is too short.")
    starts = torch.randint(0, len(ids) - block - 1, (8,))
    x = torch.stack([ids[s:s+block] for s in starts]).to(device)
    y = torch.stack([ids[s+1:s+block+1] for s in starts]).to(device)

    _, loss = model(x, y)
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    optimizer.step()

    if step % 50 == 0:
        print(f"step={step} loss={loss.item():.4f}")

torch.save(model.state_dict(), OUT / "model.pt")
print("Saved IP-AIv1 v0.1 artifacts.")
